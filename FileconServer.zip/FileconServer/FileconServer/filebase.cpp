#include "filebase.h"

filebase::filebase(QObject *parent) : QObject(parent)
{

    imageindex=0;
    sizepacklast=0;
        connect(&server,SIGNAL(newConnection()),this,SLOT(onNewConnection()));

        bool ok =server.listen(QHostAddress::AnyIPv4,8888);
        qDebug()<<"listen"<<ok;
}

void filebase::onReadReady()
{
    QObject *obj=this->sender();
    QTcpSocket *socket =qobject_cast<QTcpSocket *>(obj);
    //粘包，半包问题处理
qint64 sizeNow=0;
   do{
    //当前缓冲区大小
   sizeNow =socket->bytesAvailable();
       QDataStream stream(socket);
         if(sizepacklast==0){
            if(sizeNow<sizeof(quint32))
            {

                return;
            }

            stream>>sizepacklast;//已经有值
        }

    //包完整判断
    if(sizeNow<sizepacklast-4)
    {
     return;
   }

    int msgType =MsgTypeInvaid;

    stream >>msgType;



    //判断剩下的字节数，是否会有粘包
    sizeNow =socket->bytesAvailable();
  sizepacklast=0;
qDebug()<<msgType;

  switch (msgType) {

  case MsgTypeFile:
  {
      QByteArray dataFileContent;
      QString filename;
qDebug()<<"doFile";
      stream>>filename>>dataFileContent;
qDebug()<<filename;
qDebug()<<dataFileContent;
      emit doFile(filename,dataFileContent);
      break;
  }
  case MsgTypeDel:
  {
      QString fileDel;
      stream>>fileDel;
      qDebug()<<"doDel";
       emit doDel(fileDel);
      break;
  }
  case MsgTypeRename:
  {
      QString fileold;
      QString filenew;
        qDebug()<<"doRename";
      stream>>fileold>>filenew;
      emit doRename(fileold,filenew);
  break;
  }

  }

   }while(sizeNow>0);

}

void filebase::onNewConnection()
{
    //socket 和客户端进行通信
    QTcpSocket * socket =server.nextPendingConnection();

    client.append(socket);



       connect(socket,SIGNAL(readyRead()),this,SLOT(onReadReady()));
    connect(socket,SIGNAL(connected()),this,SLOT(onConnected()));
     connect(socket,SIGNAL(disconnected()),this,SLOT(onDisconnected()));
      connect(socket,SIGNAL(error(QAbstractSocket::SocketError)),this,SLOT(onError(QAbstractSocket::SocketError)));

}

void filebase::onConnected()
{
qDebug()<<"conntion";
}

void filebase::onDisconnected()
{
    QObject *obj=this->sender();
    QTcpSocket *socket =qobject_cast<QTcpSocket *>(obj);
    client.removeAll(socket);
socket->close();
 qDebug()<<"onDisconnected";
}

void filebase::onError(QAbstractSocket::SocketError scoketerro)
{
   qDebug()<<"onError";
}
