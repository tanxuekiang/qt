#include "widget.h"
#include "ui_widget.h"
#include <QFile>
#include<QFileInfo>
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    connect(&filebb,SIGNAL(doFile(QString,QByteArray)),this,SLOT(onFile(QString,QByteArray)));
    connect(&filebb,SIGNAL(doDel(QString)),this,SLOT(onDel(QString)));
    connect(&filebb,SIGNAL(doRename(QString,QString)),this,SLOT(onRename(QString,QString)));
    fileServerpath="C:/Users/f/Desktop/server";

}

Widget::~Widget()
{
    delete ui;
}

void Widget::onFile(const QString &filename, const QByteArray &data)
{
qDebug()<<"file"<<filename;
//filename是客户端的路径

QFileInfo fileinfoo(filename);

QString fileNameJust =fileinfoo.fileName();
QString fileNameLocal =fileServerpath +"/"+fileNameJust;
QFile file(fileNameLocal);
if(!file.open(QIODevice::WriteOnly))
{

    qDebug()<<"open faild";
}
file.write(data);
file.close();
}

void Widget::onDel(const QString &filename)
{
qDebug()<<"del"<<filename;

QFileInfo fileinfoo(filename);

QString fileNameJust =fileinfoo.fileName();
QString fileNameLocal =fileServerpath +"/"+fileNameJust;

QFile::remove(fileNameLocal);
}

void Widget::onRename(const QString &fileold, const QString &filenew)
{
qDebug()<<"rename"<<fileold<<"new name"<<filenew;
QFileInfo fileinfoold(fileold);

QString fileNameJustold =fileinfoold.fileName();
QString fileNameLocalold =fileServerpath +"/"+fileNameJustold;


QFileInfo fileinfonew(filenew);

QString fileNameJustnew=fileinfonew.fileName();
QString fileNameLocalnew =fileServerpath +"/"+fileNameJustnew;

QFile::rename(fileNameLocalold,fileNameLocalnew);
}

