#ifndef FILEBASE_H
#define FILEBASE_H

#include <QObject>
#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include<QList>
enum MsgType{

    MsgTypeInvaid =0,
MsgTypeFile,
    MsgTypeDel,
    MsgTypeRename

};
class filebase : public QObject
{
    Q_OBJECT
public:
    explicit filebase(QObject *parent = nullptr);

public slots:

    void onReadReady();


    void onNewConnection();

    void onConnected();

    void onDisconnected();
    void onError(QAbstractSocket::SocketError scoketerro);

signals:
void doFile(const QString &filename,const QByteArray &data);
void doDel(const QString &filename);
void doRename(const QString &fileold,const QString &filenew);

private:
    QTcpServer server;
    QList<QTcpSocket *> client;
    int imageindex;
     quint32 sizepacklast;
};

#endif // FILEBASE_H
