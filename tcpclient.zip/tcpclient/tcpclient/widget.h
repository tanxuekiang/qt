#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include<QTcpSocket>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
public slots:

  void onReadReady();

  void onConnected();

  void onDisconnected();
  void onError(QAbstractSocket::SocketError scoketerro);
private slots:
  void on_sen_clicked();

  void on_img_clicked();

private:
    Ui::Widget *ui;
    QTcpSocket tcpsock;
    int imageindex;
    quint32 sizepacklast;
};
#endif // WIDGET_H
