#include "widget.h"
#include "ui_widget.h"
#include <QFileDialog>
#include <QFile>
#include <QDateTime>
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    imageindex=0;
    sizepacklast=0;
    ui->setupUi(this);

    connect(&tcpsock,SIGNAL(readyRead()),this,SLOT(onReadReady()));
 connect(&tcpsock,SIGNAL(connected()),this,SLOT(onConnected()));
  connect(&tcpsock,SIGNAL(disconnected()),this,SLOT(onDisconnected()));
   connect(&tcpsock,SIGNAL(error(QAbstractSocket::SocketError)),this,SLOT(onError(QAbstractSocket::SocketError)));

   tcpsock.connectToHost("127.0.0.1",8888);
}
Widget::~Widget()
{
    delete ui;
}

void Widget::onReadReady()
{
    QObject *obj=this->sender();
    QTcpSocket *socket =qobject_cast<QTcpSocket *>(obj);
    //粘包，半包问题处理
qint64 sizeNow=0;
   do{
    //当前缓冲区大小
   sizeNow =socket->bytesAvailable();
       QDataStream stream(socket);
         if(sizepacklast==0){
            if(sizeNow<sizeof(quint32))
            {

                return;
            }

            stream>>sizepacklast;//已经有值
        }

    //包完整判断
    if(sizeNow<sizepacklast-4)
    {
     return;
   }

    qDebug()<<"full pack";
    QByteArray datafull;
    stream >>datafull;
    //判断剩下的字节数，是否会有粘包
    sizeNow =socket->bytesAvailable();
  sizepacklast=0;



        QString prefix = datafull.mid(0,4);

        QString datatime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss:");
         ui->liaotian->append(datatime);
        if(prefix=="TXT:")
        {

            QString textcon = datafull.mid(4);
          ui->liaotian->append("<p>"+textcon+"</p><br>");

        }else if(prefix=="IMG:")
        {

            QString htmll=QString("<img src=\"%1\"></img><br>");
            QString index=QString::number(imageindex++);
            htmll=htmll.arg(index+".png");

               QFile file(index+".png");
               file.open(QIODevice::WriteOnly);
               file.write(datafull.mid(4));
               file.close();

                       ui->liaotian->insertHtml(htmll);

        }


   }while(sizeNow>0);


}
void Widget::onConnected()//链接成功
{
qDebug()<<"conntion";
}

void Widget::onDisconnected()//断开
{



    QObject *obj=this->sender();
    QTcpSocket *socket =qobject_cast<QTcpSocket *>(obj);
socket->close();
 qDebug()<<"onDisconnected";
}

void Widget::onError(QAbstractSocket::SocketError scoketerro)//错误信息
{
    qDebug()<<"onError";

}

void Widget::on_sen_clicked()
{
    QString msgInput="TXT:"+ui->shuru->toPlainText();

    //封装包头
    QByteArray datasen;
    QDataStream stream(&datasen,QIODevice::WriteOnly);
    stream<<(quint32)0<<msgInput.toUtf8();
    stream.device()->seek(0);
    stream<<datasen.size();
tcpsock.write(datasen);
ui->shuru->clear();
}

void Widget::on_img_clicked()
{
    QString image =QFileDialog::getOpenFileName(this,"title",".","Image File(*.png *.jpg *.bmp)");
    if(image.isEmpty())
        return;

    QFile file(image);
    file.open(QIODevice::ReadOnly);

    QByteArray date ="IMG:"+file.readAll();
    file.close();

//封装包头
    QByteArray datasen;
    QDataStream stream(&datasen,QIODevice::WriteOnly);
    stream<<(quint32)0<<date;
    stream.device()->seek(0);
    stream<<datasen.size();


        tcpsock.write(datasen);

}
