#ifndef OPENCVMO_H
#define OPENCVMO_H

#include <QObject>
#include<opencv2/opencv.hpp>

using namespace cv;
class OpencvMo : public QObject
{
    Q_OBJECT
public:
    explicit OpencvMo(QObject *parent = nullptr);
signals:


public:

     Mat opdationDemo(Mat& image);
    void colorstyleDemo(Mat& image);
    Mat cvtColorDemo(Mat& image);
    void pixstaticDemo(Mat& image);
    void drawDemo(Mat& image);
    void randomDemo();
    void poly_drawDemo();
    void mouse_draw(Mat& image);
    Mat onChangeTrackBarConstra(int pos,Mat& image);
    void norm_demo(Mat& image);
    void resize_demo(Mat& image);
    void flip_demo(Mat& image);
    void rotato_demo(Mat& image);
    Mat blur_demo(Mat& image);
    void face_detect_demo(Mat& image);
    void face_demo(Mat& image);
};

#endif // OPENCVMO_H
