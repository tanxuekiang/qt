# qt_for_android_photochange

项目在压缩包里面
一个qt for Android 的美图app
