#include "Myclass.h"
#include <QFile>
#include <QFileInfo>
#include <QJniObject>
#include <QtCore/private/qandroidextras_p.h>
#include <QUrl>
#include <QDir>
#include<QString>
#include <QDebug>
#include <QJniEnvironment>
#include "OpencvMo.h"
#include <QtQuick/QQuickPaintedItem>
#include <QQuickItem>
#include <QFile>
Myclass::Myclass(QObject *parent) : QObject(parent) {}


QJniObject getAndroidContext() {
        QJniObject activity = QJniObject::callStaticObjectMethod("org/qtproject/qt/android/QtNative", "activity", "()Landroid/app/Activity;");
        return activity;
    }
void Myclass::CopyAndgetRealPath(const QString &contentUri)
{
    QFileInfo sddd(contentUri);
    //sddd.fileName();

    QString dir="/storage/emulated/0/Download/";
       QString timenow= QDateTime::currentDateTime().toString("hh-mm-ss-zzz");
        QString destPath=dir+timenow+".jpg";


 QFile destFile(contentUri);

     if ( destFile.copy(contentUri,destPath)) {
     qDebug() << "复制成功！";
 } else {
     qDebug() << "复制失败，错误：" <<destFile.errorString();
 }

 geturltosave(destPath);

emit dataReceived(destPath);

        return;
}
void Myclass::requestOpencv(const QString &contentUri,int funtionNum)
{

    QString storurl =getuurl;

    OpencvMo opencvdeal;

    QImage image(storurl);


    Mat mat=qimagetomat(image);//qimage 转换mat 灰度图等格式

    Mat temp;
    switch(funtionNum)
    {
    case 1:
       temp=opencvdeal.blur_demo(mat);//灰度修改修改;
        break;
    case 2:
        temp=opencvdeal.cvtColorDemo(mat);
        break;
    case 3:
        temp=opencvdeal.onChangeTrackBarConstra(this->slidenum,mat);
        break;
    }

bool savemat=imwrite(storurl.toStdString(),temp);//保存




emit dataReceived(storurl);
  if(savemat==true)
   {
        qDebug()<<"保存成功"<<savemat<<this->slidenum;
       return;
}
   else{

       return;
   }

}
void Myclass::getsliderturn(int funtionNum)
{
    this->slidenum=funtionNum;
}
void Myclass::geturltosave(QString geturl)
{
    this->getuurl=geturl;
}
QImage Myclass::mattoqimage(Mat mat)
{
    switch(mat.type())  {
    case CV_8UC1: { // 灰度图
        QImage img(mat.data,  mat.cols,  mat.rows,
                   mat.step,  QImage::Format_Grayscale8);
        return img.copy();  // 深拷贝避免悬垂指针
    }
    case CV_8UC3: { // BGR转RGB
        cv::Mat rgbMat;
        cv::cvtColor(mat, rgbMat, cv::COLOR_BGR2RGB);
        QImage img(rgbMat.data,  rgbMat.cols,  rgbMat.rows,
                   rgbMat.step,  QImage::Format_RGB888);
        return img.copy();
    }
    case CV_8UC4: { // RGBA格式
        QImage img(mat.data,  mat.cols,  mat.rows,
                   mat.step,  QImage::Format_ARGB32);
        return img.copy();
    }
    default:
        return QImage();
}
}
Mat Myclass::qimagetomat(QImage image)
{
    switch (image.format())  {
    case QImage::Format_RGB32: { // 32位RGB（实际存储为BGRA）
        Mat mat(image.height(),  image.width(),  CV_8UC4, image.bits(),  image.bytesPerLine());
        cvtColor(mat, mat, cv::COLOR_BGRA2BGR);  // 可选：去除透明通道
        return mat;
    }
    case QImage::Format_RGB888: { // 24位RGB
        Mat mat(image.height(),  image.width(),  CV_8UC3, image.bits(),  image.bytesPerLine());
        return mat;
    }
    case QImage::Format_Grayscale8: { // 8位灰度
        Mat mat(image.height(),  image.width(),  CV_8UC1, image.bits(),  image.bytesPerLine());
        return mat;
    }
    default:
        return Mat();
    }
}
