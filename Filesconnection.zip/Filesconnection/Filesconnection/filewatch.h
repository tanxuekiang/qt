#ifndef FILEWATCH_H
#define FILEWATCH_H

#include <QWidget>
#include<QFileSystemWatcher>
class filewatch : public QWidget
{
    Q_OBJECT
public:
    explicit filewatch(QWidget *parent = nullptr);
    void setwatchpath(const QString &path);
private slots:

   void onDirectoryChanged(const QString &path);


   void onFileChange(const QString &path);

signals:
   void doFileadd(const QString &file);
   void doFileRemove(const QString &file);
   void doFileChange(const QString &file);
   void doFileRename(const QString &oldname,const QString &newname);

private:
   QFileSystemWatcher watch;
   QStringList filetest();
   QString pathWatch;
   QStringList fileold;
};

#endif // FILEWATCH_H
