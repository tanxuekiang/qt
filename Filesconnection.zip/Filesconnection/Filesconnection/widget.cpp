#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
watcc.setwatchpath("D:/test");
connect(&watcc,SIGNAL(doFileadd(QString)),this,SLOT(onFileadd(QString)));
connect(&watcc,SIGNAL(doFileRemove(QString)),this,SLOT(onFileRemove(QString)));
connect(&watcc,SIGNAL(doFileChange(QString)),this,SLOT(onFileChange(QString)));
connect(&watcc,SIGNAL(doFileRename(QString,QString)),this,SLOT(onFileRename(QString,QString)));
}

Widget::~Widget()
{
    delete ui;
}

void Widget::onFileadd(const QString &file)
{
    qDebug()<<"add file";
filetran.sendFile(file);
}

void Widget::onFileRemove(const QString &file)
{
    qDebug()<<"FileRemove";
filetran.sendDel(file);
}

void Widget::onFileChange(const QString &file)
{
    qDebug()<<"FileChange";
filetran.sendFile(file);
}

void Widget::onFileRename(const QString &oldname, const QString &newname)
{
qDebug()<<"FileRename";
filetran.sendRename(oldname,newname);
}

