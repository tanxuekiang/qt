#include "filetrans.h"
#include<QDataStream>
#include<QFile>
filetrans::filetrans(QObject *parent) : QObject(parent)
{

    connect(&tcpsock,SIGNAL(readyRead()),this,SLOT(onReadReady()));
 connect(&tcpsock,SIGNAL(connected()),this,SLOT(onConnected()));
  connect(&tcpsock,SIGNAL(disconnected()),this,SLOT(onDisconnected()));
   connect(&tcpsock,SIGNAL(error(QAbstractSocket::SocketError)),this,SLOT(onError(QAbstractSocket::SocketError)));

   tcpsock.connectToHost("127.0.0.1",8888);
}

void filetrans::sendFile(const QString &filename)
{

    qDebug()<<"test 断点";
    //读取文件
    QByteArray datafilecontent;

 qDebug()<<"文件名filename"<<filename;
    QFile file(filename);
    if(!file.open(QIODevice::ReadOnly))
    {
       qDebug()<<"open file faild";
       return;

    }
    datafilecontent=file.readAll();
file.close();
    //封装包头
        QByteArray datasen;
        QDataStream stream(&datasen,QIODevice::WriteOnly);
        stream<<(quint32)0<<MsgTypeFile<<filename<<datafilecontent;
        stream.device()->seek(0);

        stream<<datasen.size();

            tcpsock.write(datasen);

}

void filetrans::sendDel(const QString &filename)
{
    //封装包头
    QByteArray datasen;
    QDataStream stream(&datasen,QIODevice::WriteOnly);
    stream<<(quint32)0<<MsgTypeDel<<filename;
    stream.device()->seek(0);
    stream<<datasen.size();
///
        tcpsock.write(datasen);
}

void filetrans::sendRename(const QString &fileold, const QString &filenew)
{
    QByteArray datasen;
    QDataStream stream(&datasen,QIODevice::WriteOnly);
    stream<<(quint32)0<<MsgTypeRename<<fileold<<filenew;
    stream.device()->seek(0);
    stream<<datasen.size();

        tcpsock.write(datasen);
}

void filetrans::onReadReady()
{

}

void filetrans::onConnected()
{
qDebug()<<"conntion";
}

void filetrans::onDisconnected()
{
    QObject *obj=this->sender();
    QTcpSocket *socket =qobject_cast<QTcpSocket *>(obj);
socket->close();
 qDebug()<<"onDisconnected";
}

void filetrans::onError(QAbstractSocket::SocketError scoketerro)
{
 qDebug()<<"onError";
}
