#include "filewatch.h"
#include<QDebug>
#include<QDir>
filewatch::filewatch(QWidget *parent) : QWidget(parent)
{
    connect(&watch,SIGNAL(directoryChanged(QString)),this,SLOT(onDirectoryChanged(QString)));
    connect(&watch,SIGNAL(fileChanged(QString)),this,SLOT(onFileChange(QString)));
}

void filewatch::setwatchpath(const QString &path)
{
  pathWatch=path;
   qDebug()<<"pathWatch"<<path;
  QStringList filemuch=this->filetest();

    watch.addPaths(filemuch);
     watch.addPath(path);
//监听的文件列表
     fileold=watch.files();
}

void filewatch::onDirectoryChanged(const QString &path)
{
    qDebug()<<"dir change"<<path;
    //当前文件列表
    QStringList filenow=this->filetest();
    //之前的文件列表fileold

    if(filenow.count()>fileold.count())
    {
        //获取新建文件名
       foreach(QString ofile,fileold)
       {
         filenow.removeAll(ofile);
       }
       watch.addPaths(filenow);
       fileold=watch.files();
       emit doFileadd(filenow.first());
        qDebug()<<"create"<<filenow;
    }




}

void filewatch::onFileChange(const QString &path)
{
    QStringList fileWatchcc=watch.files();

//监听列表里面还包含path，传进来的文件，说明文件还在，只是发生了改变
if(fileWatchcc.contains(path))
{
    emit doFileChange(path);
 qDebug()<<"file change";


}else
{
    QStringList fileNow=this->filetest();
    if(fileNow.count()==fileold.count())
     {

            foreach(QString wfile,fileold){
                fileNow.removeAll(wfile);
            }
             watch.addPaths(fileNow);
             emit doFileRename(path,fileNow.first());
            qDebug()<<"rename old"<<path<< " new name "<<fileNow;

    }
    else {//删除
        emit doFileRemove(path);
        qDebug()<<"file delete "<<path;

    }


}
fileold=watch.files();
}

QStringList filewatch::filetest()
{
    QDir dir(pathWatch);
    QFileInfoList infoList = dir.entryInfoList(QDir::Files);


    QStringList ret;

    foreach(QFileInfo info,infoList)
    {

        ret.append(info.absoluteFilePath());

    }

return ret;




}
