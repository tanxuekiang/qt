#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include<QFileSystemWatcher>
#include "filewatch.h"
#include "filetrans.h"
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
private slots:
    void onFileadd(const QString &file);
    void onFileRemove(const QString &file);
    void onFileChange(const QString &file);
    void onFileRename(const QString &oldname,const QString &newname);
private:
    Ui::Widget *ui;
    filewatch watcc;
    filetrans filetran;
};
#endif // WIDGET_H
