#ifndef FILETRANS_H
#define FILETRANS_H

#include <QObject>
#include <QTcpSocket>
enum MsgType{

    MsgTypeInvaid =0,
MsgTypeFile,
    MsgTypeDel,
    MsgTypeRename

};
class filetrans : public QObject
{
    Q_OBJECT
public:
    explicit filetrans(QObject *parent = nullptr);

   void sendFile(const QString &filename);
   void sendDel(const QString &filename);
    void sendRename(const QString &fileold,const QString &filenew);



signals:


public slots:
    void onReadReady();

    void onConnected();

    void onDisconnected();
    void onError(QAbstractSocket::SocketError scoketerro);
private:
    QTcpSocket tcpsock;

};

#endif // FILETRANS_H
