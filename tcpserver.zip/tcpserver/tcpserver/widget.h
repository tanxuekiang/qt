#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include<QList>
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();


public slots:

  void onReadReady();


  void onNewConnection();

  void onConnected();

  void onDisconnected();
  void onError(QAbstractSocket::SocketError scoketerro);
private slots:
  void on_pushButton_2_clicked();

  void on_img_clicked();

private:
    Ui::Widget *ui;
    QTcpServer server;
    QList<QTcpSocket *> client;
    int imageindex;
     quint32 sizepacklast;
};
#endif // WIDGET_H
