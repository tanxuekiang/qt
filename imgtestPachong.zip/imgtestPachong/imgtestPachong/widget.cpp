#include "widget.h"
#include "ui_widget.h"
#include <QWebView>
#include<QWebSettings>
#include<QWebElementCollection>
#include <QWebFrame>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QNetworkAccessManager>
#include <QFileInfo>
#include<QTimer>



Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    view =new QWebView(this);
     ui->lay->addWidget(view);
qDebug() << "OpenSSL支持情况:" << QSslSocket::supportsSsl();
qDebug()<<"QSslSocket="<<QSslSocket::sslLibraryBuildVersionString();


QWebSettings *sett=view->settings();
//设置程序不显示图片和js
sett->setAttribute(QWebSettings::AutoLoadImages,false);
sett->setAttribute(QWebSettings::JavaEnabled,false);

connect(view,SIGNAL(loadProgress(int)),this,SLOT(onProgress(int)));
connect(view,SIGNAL(loadFinished(bool)),this,SLOT(onLoadFinished(bool)));
Dwindows.show();
}

Widget::~Widget()
{
    delete ui;
    qDeleteAll(mgrs);
}

void Widget::closeEvent(QCloseEvent *event)
{
    QWidget::closeEvent(event);
    foreach(QNetworkAccessManager*mgr,mgrs)
    {

        mgr->deleteLater();
    }
    mgrs.clear();

}


void Widget::on_pushButton_clicked()
{
QUrl url=ui->lineEdit->text();
view->load(url);
}

void Widget::onProgress(int progress)
{
    //进度显示
    QString title=QString::number(progress)+"%";
    this->setWindowTitle(title);

}

void Widget::onLoadFinished(bool ok)
{


            qDebug()<<"finish"<<ok;
            //取网页的的照片标签
            QWebElementCollection element=view->page()->mainFrame()->findAllElements("body> div.container.container-default > main > section > ul > li > article > a > img");




            //循环遍历当前网页的照片标签并保存默认目录
            for(int i=0;i<element.count();++i)
            {
                update();

            const QWebElement &ele=element.at(i);
            QString url=ele.attribute("src");
            qDebug()<<url;

            //那url 放入容器list
               QStringList listurl;
            listurl.append(url);

                    /*
            QImage image=loadimg(url);

            QFileInfo info(url);

            QString fileName=info.fileName();
            image.save(fileName);
  qDebug()<<"断点2";
            Dwindows.setImage(image);

  qDebug()<<"断点5";
            qDebug()<<"保存的图片名称  "<<fileName;

            //延时5秒钟
            QEventLoop loop;
            QTimer::singleShot(10*1000,&loop,SLOT(quit()));
            loop.exec();
            update();

*/

      //多线程下载一组图片
                    downloadimagess(listurl);



}

            //通过谷歌浏览器可以得到网页下一页的标签为a.next，
          QString test="#tuchong-com > div.container.container-default > main > section > div > div > div > a.next";
           element = view->page()->mainFrame()->findAllElements(test);

            //只取10页的照片
          if(element.count()>=10)
          {

               qDebug()<<"没有了";
               return;
           }


            const QWebElement &ele=element.at(0);



            //当前网页的网站显示为https://landscape.tuchong.com/?page=，  通过谷歌浏览器可以知道href标签的值为?page=，这里是页数
            QString urlnext="https://landscape.tuchong.com/"+ele.attribute("href");
            qDebug()<<urlnext;
            QUrl nexturl=urlnext;
            //加载新网页
            view->load(nexturl);




}

QImage Widget::loadimg(const QString &url)
{
    QNetworkAccessManager mgr;
 QNetworkReply *rep=mgr.get(QNetworkRequest (QUrl(url)));
 QEventLoop loop;
 connect(rep,SIGNAL(finished()),&loop,SLOT(quit()));
 //卡住等待结束（quit）
 loop.exec();

 QByteArray date=rep->readAll();

 QImage image =QImage::fromData(date);
  qDebug()<<"断点1";
 return image;

}
void Widget::onDownlodaFinshed()
{
 qDebug()<<"断点1";
    QObject *obj=this->sender();
    QNetworkReply* rep=qobject_cast<QNetworkReply*>(obj);//dynamic_cast 父类转子类指针

    if(rep==NULL)
    {
        return;
    }

    QByteArray date=rep->readAll();


    QNetworkAccessManager *mgr=rep->manager();




    mgrs.removeAll(mgr);

    mgr->deleteLater();

    QImage image =QImage::fromData(date);


     QFileInfo info(rep->url().toString());

     QString fileName=info.fileName();
     image.save(fileName);

     if(remurls.isEmpty())
     {
         return;
     }

QStringList lone;
lone<<remurls.takeFirst();
     downloadimagess(lone);
}
void Widget::downloadimagess(const QStringList &urls)
{

    foreach(const QString &url,urls){

     if(mgrs.count()>10)
     {
         remurls<<url;
         continue;

     }
    QNetworkAccessManager *mgr=new QNetworkAccessManager();


    mgrs<<mgr;
    QNetworkRequest requst;
    requst.setUrl(QUrl(url));
    QNetworkReply *rep=mgr->get(requst);

connect(rep,SIGNAL(finished()),this,SLOT(onDownlodaFinshed()));
}

}
