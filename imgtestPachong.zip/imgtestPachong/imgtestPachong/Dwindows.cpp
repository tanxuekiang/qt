#include "Dwindows.h"
#include<QPainter>
#include<QImage>
#include <windows.h>
#include <QScreen>
#include <QGuiApplication>
#include <QDesktopWidget>
#include<QDebug>
#include<QTimer>

//寻照windows窗口句柄
static HWND g_workerw=0;
static BOOL CALLBACK EnumWndCallback(HWND tophandle,LPARAM toopparamhandle)
{

    HWND p=FindWindowEx(tophandle,0,L"SHELLDLL_DefView",0);
    if(p!=0)
    {

        g_workerw = FindWindowEx(0,tophandle,L"WorkerW",0);

    }
    return true;
}

Dwindows::Dwindows(QWindow *parent)
    : QWindow(parent),store(this)
{

    //构造函数使用windows窗口下的句柄
    HWND hwnProgram =FindWindow(L"Progman",L"Program Manager");
    SendMessageTimeout(hwnProgram,0x052C,0,0,SMTO_NORMAL,1000,0);
    EnumWindows(EnumWndCallback,0);


    //判断是否找到句柄
    if(g_workerw == 0)
    {
        abort();

     }
    QWindow * windestop=QWindow::fromWinId((WId)g_workerw);

    this->setParent(windestop);


    //使用QScreen 类获取桌面分辨率

    QScreen* screen= QGuiApplication::primaryScreen();

    //qDebug()<<screen->availableGeometry();
    //QRect rectFullDES=screen->availableGeometry();


    this->setGeometry(screen->availableGeometry());

imge=QImage("C:/Users/f/Desktop/1.jpg");

}

Dwindows::~Dwindows()
{

}

bool Dwindows::event(QEvent *e)
{

    //放入想要放入的图片路径

//if(e->type()==QEvent::Expose || e->type()==QEvent::Resize){
        QRect rect(QPoint(0,0),this->size());
        store.resize(this->size());
        store.beginPaint(rect);
        QPainter painter(store.paintDevice());
        //painter.fillRect(rect,Qt::white);
       // painter.drawText(10,10,"hahaha");


      painter.drawImage(0,0,imge);

painter.end();

    store.endPaint();

      store.flush(rect);
//}

 //qDebug()<<QWindow::event(e);
    return QWindow::event(e);
}

void Dwindows::setImage(QImage &imagee)
{ qDebug()<<"断点3";
 Dwindows::event(e1);
    this->imge=imagee;

    QDesktopWidget w;

    QRect rectfull=w.availableGeometry();

    int x=(rectfull.width()-imagee.width())/2;
    int y=(rectfull.height()-imagee.height())/2;

    this->setGeometry(x,y,imagee.width(),imagee.height());
}
