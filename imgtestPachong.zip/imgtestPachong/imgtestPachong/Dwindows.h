#ifndef DWINDOWS_H
#define DWINDOWS_H

#include <QWindow>
#include<QBackingStore>
#include <QWidget>
class Dwindows : public QWindow
{
    Q_OBJECT

public:
    Dwindows(QWindow *parent = nullptr);
    ~Dwindows();
    bool event(QEvent *e);
    void setImage(QImage &imagee);
    QBackingStore store;
 QImage imge;
 QEvent *e1;
};
#endif // WIDGET_H
