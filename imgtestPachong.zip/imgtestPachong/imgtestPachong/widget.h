#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QtWebKitWidgets/QWebView>
#include<QWebSettings>
#include<QWebElementCollection>
#include <QtWebKit/qwebsettings.h>
#include "Dwindows.h"
#include <QWebFrame>
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE
class QNetworkAccessManager;
class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
   QWebView *view; //建立qwebview 类来读取url
void closeEvent(QCloseEvent *event);

public slots:
    void on_pushButton_clicked();
    void onProgress(int progress);//加载进度显示
    void onLoadFinished(bool ok);//判断是否加载完成
    void onDownlodaFinshed();



private:
    //下载图片函数
QImage loadimg(const QString &url);
void downloadimagess(const QStringList &urls);
    Ui::Widget *ui;
    Dwindows Dwindows;
//只是指针不去new。不去调用函数不需要包含头文件，只需要class声明
    QList<QNetworkAccessManager*> mgrs;
    QStringList remurls;
};
#endif // WIDGET_H
